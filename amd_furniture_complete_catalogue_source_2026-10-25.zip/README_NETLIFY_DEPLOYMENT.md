# AMD FURNITURE UK - COMPLETE CATALOGUE EXPORT PACKAGE

This archive contains all 18 products and their uploaded images added via the AMD Furniture UK admin panel.

## Folder Structure
- `src/data/products.json`: The master catalogue file.
- `public/data/products.json`: Static catalogue fallback for Netlify.
- `public/images/products/`: All uploaded product images.

## Netlify Deployment Steps:
1. Extract this zip file into your AMD Furniture UK project folder to ensure all latest products and images are updated.
2. Run `npm run build` to verify production build.
3. Push to your Git repository (GitHub / GitLab) connected to Netlify, or drag-and-drop the `dist` folder into Netlify.
4. Your website is live with all products, colors, swatches, and images!
